//timers - for scheduling and canceling functions to be executed at a later time

// Set a timeout to run code after a delay
setTimeout(() => {
    console.log('Delayed response');
  }, 1000);
  
  // Set an interval to run code repeatedly
  const interval = setInterval(() => {
    console.log('Repeated code');
  }, 1000);
  
  // Cancel the interval after 5 seconds
  setTimeout(() => {
    clearInterval(interval);
  }, 5000);