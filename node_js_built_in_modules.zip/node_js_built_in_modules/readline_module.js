//readline is used for creating command line interfaces (CLI).


const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('Welcome,What is your name? ', (name) => {
  console.log(`Hello, ${name}!, how may I be of help?`);
  rl.close();
});