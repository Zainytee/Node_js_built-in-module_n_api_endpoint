//http2 - for creating HTTP/2 servers and clients


const http2 = require('http2');
const fs = require('fs')

// Create an HTTP/2 server using the `http2.createSecureServer` function
const server = http2.createSecureServer({
  cert: fs.readFileSync('cert.pem'),
  key: fs.readFileSync('key.pem')
}, (req, res) => {
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello, world!');
});

server.listen(3000, () => {
  console.log('Server listening on port 3000');
});

// Create an HTTP/2 client using the `http2.connect` function
const client = http2.connect('https://localhost:3000', {
  ca: fs.readFileSync('cert.pem')
});

const req = client.request({
  ':method': 'GET',
  ':path': '/'
});

req.on('response', (headers, flags) => {
  console.log(headers);
});

req.on('data', (data) => {
  console.log(data.toString());
});

req.on('end', () => {
  client.close();
});
