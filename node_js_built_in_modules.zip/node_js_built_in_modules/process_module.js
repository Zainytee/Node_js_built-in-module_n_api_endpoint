//process is used for interacting with the current Node.js process

console.log('Process ID:', process.pid);
console.log('Process version:', process.version);
console.log('Command-line arguments:', process.argv);
console.log('Environment variables:', process.env);
console.log('Working directory:', process.cwd());
console.log('Memory usage:', process.memoryUsage());
console.log('Uptime:', process.uptime());