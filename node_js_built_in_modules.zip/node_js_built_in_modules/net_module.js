//net is used for creating network servers and clients

const net = require('net');

const server = net.createServer(socket => {
  // New client connection handler
  console.log('Client connected.');

  // Send a welcome message to the client
  socket.write('Welcome to the server!');

  // Handle incoming data from the client
  socket.on('data', data => {
    console.log(`Received data: ${data}`);
  });

  // Handle client disconnection
  socket.on('close', () => {
    console.log('Client disconnected.');
  });
});

server.listen(3000, () => {
  console.log('Server started and listening on port 8000.');
});
