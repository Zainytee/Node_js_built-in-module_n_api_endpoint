// os module is used for retrieving information about the operating system. Below is the code example of how it works;

const os = require('os');

console.log(`Total memory: ${os.totalmem()}`);
console.log(`Free memory: ${os.freemem()}`);
console.log(`CPU architecture: ${os.arch()}`);