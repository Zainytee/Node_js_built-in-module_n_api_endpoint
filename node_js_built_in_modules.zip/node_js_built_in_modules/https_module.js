//https module is used to make Node.js act as an HTTPS server

const https = require('https');
const fs = require('fs');

const options = {
  key: fs.readFileSync('/path/to/ssl-key.pem'),
  cert: fs.readFileSync('/path/to/ssl-cert.pem')
};

// Create an HTTPS server
const server = https.createServer(options, (req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello, world!\n');
});

// Start the server listening on port 3000
server.listen(3000, () => {
  console.log('Server listening on port 3000');
});

// Make an HTTPS request to another server
https.get('https://www.example.com/', (res) => {
  console.log(`Status code: ${res.statusCode}`);
  console.log(`Headers: ${JSON.stringify(res.headers)}`);

  res.setEncoding('utf8');
  res.on('data', (chunk) => {
    console.log(`Received data: ${chunk}`);
  });
});
