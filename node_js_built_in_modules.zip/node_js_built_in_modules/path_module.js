// path module is used for working with the file path. Below is an example of how it works;


const path = require('path');

const filePath = path.join(__dirname, 'file.txt');
console.log(filePath);