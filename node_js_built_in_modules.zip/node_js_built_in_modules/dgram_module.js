//dgram is used for creating datagram sockets for UDP communication
const dgram = require('dgram');

const socket = dgram.createSocket('udp4');

// Send a message over UDP
const message = Buffer.from('Hello, Zeeworld!');
socket.send(message, 0, message.length, 8000, 'localhost', (err) => {
  if (err) throw err;
  console.log('Message sent');
});

// Receive messages over UDP
socket.on('message', (message, rinfo) => {
  console.log(`Received message: ${message.toString()} from ${rinfo.address}:${rinfo.port}`);
});