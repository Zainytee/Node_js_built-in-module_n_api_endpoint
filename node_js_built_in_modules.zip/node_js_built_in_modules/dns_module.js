// dns module is used for resolving DNS

const dns = require('dns');

dns.lookup('google.com', (err, address) => {
  console.log(address); 
});

dns.resolve4('google.com', (err, addresses) => {
  console.log(addresses); 
});