//tls - for creating TLS/SSL encrypted connections
const tls = require('tls');
const fs = require('fs');

const options = {
  key: fs.readFileSync('/path/to/ssl-key.pem'),
  cert: fs.readFileSync('/path/to/ssl-cert.pem')
};

// Create a secure server
const server = tls.createServer(options, (socket) => {
  console.log('Client connected');

  socket.write('Hello, world!\n');
  socket.on('data', (data) => {
    console.log(`Received data: ${data}`);
  });
});

// Start the server listening on port 3000
server.listen(3000, () => {
  console.log('Server listening on port 3000');
});

// Create a secure client
const client = tls.connect(3000, () => {
  console.log('Connected to server');

  client.write('Hello, server!\n');
  client.on('data', (data) => {
    console.log(`Received data: ${data}`);
  });
});