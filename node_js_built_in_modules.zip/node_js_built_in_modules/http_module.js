//http Module is used for making Node.js act as an HTTP server. Below is an example the code snippet of how it works


var http = require('http');
var date_ = require('./date')

exports.myDateTime = function () {
    return Date();
  };



  http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write("My nation's current date and time are : " + date_.myDateTime());
    res.end();
  }).listen(8080);exports.myDateTime = function () {
    return Date();
  };
