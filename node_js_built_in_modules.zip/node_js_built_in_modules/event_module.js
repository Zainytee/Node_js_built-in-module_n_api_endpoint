//events module is used for implementing and handling events, See below example


const EventEmitter = require('events');

class MyEmitter extends EventEmitter {}

const myEmitter = new MyEmitter();

myEmitter.on('event', () => {
  console.log('An event just occurred!');
});

myEmitter.emit('event');