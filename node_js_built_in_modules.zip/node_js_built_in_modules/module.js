//module is used for working with modules in Node.js

// Defining the function that we want to export
function greeting(name) {
    return `Hello, ${name}!`;
  }
  
  // Exporting  the function as a module
  module.exports = greeting;