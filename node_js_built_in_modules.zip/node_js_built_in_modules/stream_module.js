//stream is used for working with streaming data.

const fs = require('fs');
const { Transform } = require('stream');

// Create a transform stream that converts text to uppercase
const upperCaseTransform = new Transform({
  transform(chunk, encoding, callback) {
    this.push(chunk.toString().toUpperCase());
    callback();
  }
});

// Read a file and pipe it through the transform stream to convert the text to uppercase
fs.createReadStream('./file.txt')
  .pipe(upperCaseTransform)
  .pipe(process.stdout);