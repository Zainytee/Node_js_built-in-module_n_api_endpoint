// util is used to access various utility functions
//Format a string using the arguments "Husband" and "6":


var util = require('util');
var message_ = 'Happy %dth Wedding Annivasary my beloved %s!';
var result = util.format(message_, 6, 'Husband');
console.log(result);

