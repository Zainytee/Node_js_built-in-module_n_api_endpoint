//vm - for running JavaScript code in a virtual machine


const vm = require('vm');

// Run a script in a sandboxed environment using the `vm.runInNewContext` function
const contextt = { foo: 'bar' };
vm.runInNewContext('console.log(foo);', contextt);

// Compile a script and run it in a sandboxed environment using the `vm.createContext` function
const script = new vm.Script('console.log(foo);');
const context = vm.createContext({ foo: 'bar' });
script.runInContext(context);