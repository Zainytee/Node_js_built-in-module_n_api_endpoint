//worker_threads is used for creating and managing worker threads
const { Worker } = require('worker_threads');

// Create a worker thread using the `Worker` class
const worker = new Worker(`
  const { parentPort } = require('worker_threads');

  parentPort.on('message', (message) => {
    console.log(message);
  });

  parentPort.postMessage('Hello, world!');
`);

worker.on('message', (message) => {
  console.log(message);
});






