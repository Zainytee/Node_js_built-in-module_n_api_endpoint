//querystring is used for parsing and formatting query strings

const querystring = require('querystring');

const params = { name: 'Tola', age: 20 };

// Encode an object as a query string
const encoded = querystring.stringify(params);
console.log(encoded); // name=Tola&age=20

// Decode a query string into an object
const decoded = querystring.parse(encoded);
console.log(decoded); // { name: 'Tola', age: '20' }