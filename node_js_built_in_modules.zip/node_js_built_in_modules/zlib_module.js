// zlib is used for compressing and decompressing data using gzip or deflate algorithms.


const zlib = require('zlib');

const uncompressed = 'Hello, world!'.repeat(1000);


// Compress the data using gzip
zlib.gzip(uncompressed, (err, compressed) => {
  if (err) throw err;
  console.log(`Uncompressed size: ${uncompressed.length}`);
  console.log(`Compressed size: ${compressed.length}`);
});

// Decompress the data using gzip
/*zlib.gunzip(compressed, (err, uncompressed) => {
  if (err) throw err;
  console.log(uncompressed.toString());
}); */