//buffer is used for handling binary data, including streams of raw data or data in formats
//such as JSON or XML

const buffer = Buffer.alloc(10, 'hello');

console.log(buffer); 
console.log(buffer.toString());