//assert - for writing assertions in tests

const assert = require('assert');

function add(e, f) {
  return e + f;
}

const result = add(6, 10);
assert.strictEqual(result, 16, 'Expected the value is 16');