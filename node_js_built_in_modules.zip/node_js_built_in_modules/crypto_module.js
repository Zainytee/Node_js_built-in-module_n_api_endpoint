//crypto is used for implementing cryptographic functions

const crypto = require('crypto');

const secret = 'abcdefg';
const hash = crypto.createHmac('sha256', secret)
                   .update('hello')
                   .digest('hex');

console.log(hash);