//tty is used for interacting with terminal devices

const tty = require('tty');

// Check if stdin is a terminal device
if (tty.isatty(process.stdin)) {
  console.log('stdin is a terminal device');
}

// Set the terminal window title
process.stdout.write('\x1b]2;My Working Terminal Title\x1b[00op');